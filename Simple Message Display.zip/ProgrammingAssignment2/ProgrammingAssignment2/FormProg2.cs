﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProgrammingAssignment2
{
    public partial class FormProg2 : Form
    {
        public FormProg2()
        {
            InitializeComponent();
        }

        private void ButtonShowMessage_Click(object sender, EventArgs e)
        {
            MessageBox.Show(textBoxInput.Text, "The message is ...");
        }

        private void FormProg2_Load(object sender, EventArgs e)
        {
            this.CenterToScreen();
        }
    }
}
